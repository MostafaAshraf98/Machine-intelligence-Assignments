# Search Agents
This code is based on [Eng. Yahia's](https://github.com/yahiaetman) skeleton for the Search Agents Problem Set.

**CMP402: Machine Intelligence**, Fall 2021.